# AGENTS.md — Harmony Gates

## Mission

Build a native Android tablet jazz-harmony game in Kotlin/Jetpack Compose with a USB MIDI keyboard as the primary controller.

## Hard constraints

- Kotlin application code.
- Compose UI.
- Music correctness lives in `core:music`.
- MIDI access goes through `MidiInputSource`.
- No microphone chord recognition for scoring.
- No network requirement for core play.
- No C++/NDK in the baseline implementation.
- Do not change musical behavior merely to simplify UI.
- Do not implement final aesthetics before the approved Figma phase; use a clean placeholder design system first.

## Required workflow

Before changing code, read the relevant numbered documents in this pack.

For every phase:

1. inspect repo and current status
2. implement the smallest coherent phase slice
3. add/update tests
4. run `./gradlew test`
5. run `./gradlew lint`
6. run `./gradlew assembleDebug`
7. update `docs/IMPLEMENTATION_STATUS.md`
8. commit/PR before starting dependent phase

## Architecture boundaries

`core:music` must be pure Kotlin/JVM where possible.

UI may ask the domain layer:

```text
What should I display?
Was this attempt valid?
What error occurred?
What skill evidence changed?
```

UI must not answer these itself.

## No silent theory assumptions

If a chord/voicing rule is ambiguous, represent the ambiguity in `VoicingPolicy` or content. Do not add a global universal rule unless the specification explicitly requires it.

## Test rule

Any fixed bug involving chord identity, spelling, MIDI capture, or scoring requires a regression test reproducing the failure.
