# Architecture Decision Log

## ADR-XXXX: Title

**Status:** proposed / accepted / superseded

**Context:**

**Decision:**

**Consequences:**

**Alternatives considered:**
